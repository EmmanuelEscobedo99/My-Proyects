﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAC_VALES.Web.Models
{
    public class AdeudosClientesChartData
    {
        public string EmailCliente { get; set; }
        public double AdeudoCliente { get; set; }
        public string EmpresaDisplay { get; set; }
    }
}