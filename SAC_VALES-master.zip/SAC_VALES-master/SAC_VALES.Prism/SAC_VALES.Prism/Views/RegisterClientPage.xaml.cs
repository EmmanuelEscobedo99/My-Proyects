﻿using Xamarin.Forms;

namespace SAC_VALES.Prism.Views
{
    public partial class RegisterClientPage : ContentPage
    {
        public RegisterClientPage()
        {
            InitializeComponent();
        }
    }
}
