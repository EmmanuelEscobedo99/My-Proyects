﻿using Xamarin.Forms;

namespace SAC_VALES.Prism.Views
{
    public partial class PickClientPage : ContentPage
    {
        public PickClientPage()
        {
            InitializeComponent();
        }
    }
}
