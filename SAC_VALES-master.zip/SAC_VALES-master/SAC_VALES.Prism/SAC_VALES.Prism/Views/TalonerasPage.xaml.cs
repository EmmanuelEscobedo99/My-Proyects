﻿using Xamarin.Forms;

namespace SAC_VALES.Prism.Views
{
    public partial class TalonerasPage : ContentPage
    {
        public TalonerasPage()
        {
            InitializeComponent();
        }
    }
}
