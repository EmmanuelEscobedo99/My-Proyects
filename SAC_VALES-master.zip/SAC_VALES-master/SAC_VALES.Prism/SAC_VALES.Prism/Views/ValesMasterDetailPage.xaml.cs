﻿using Xamarin.Forms;

namespace SAC_VALES.Prism.Views
{
    public partial class ValesMasterDetailPage : MasterDetailPage
    {
        public ValesMasterDetailPage()
        {
            InitializeComponent();
        }
    }
}