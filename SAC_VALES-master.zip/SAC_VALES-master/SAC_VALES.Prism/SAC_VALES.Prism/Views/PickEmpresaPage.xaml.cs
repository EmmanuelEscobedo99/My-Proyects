﻿using Xamarin.Forms;

namespace SAC_VALES.Prism.Views
{
    public partial class PickEmpresaPage : ContentPage
    {
        public PickEmpresaPage()
        {
            InitializeComponent();
        }
    }
}
