﻿using Xamarin.Forms;

namespace SAC_VALES.Prism.Views
{
    public partial class PagosCliePage : ContentPage
    {
        public PagosCliePage()
        {
            InitializeComponent();
        }
    }
}
