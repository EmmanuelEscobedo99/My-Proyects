﻿using Xamarin.Forms;

namespace SAC_VALES.Prism.Views
{
    public partial class HistoryPage : ContentPage
    {
        public HistoryPage()
        {
            InitializeComponent();
        }
    }
}
