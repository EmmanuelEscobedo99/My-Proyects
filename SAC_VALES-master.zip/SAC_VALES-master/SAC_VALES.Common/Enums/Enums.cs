﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SAC_VALES.Common.Enums
{
   public enum UserType
    {
        Admin,
        Distribuidor,
        Cliente,
        Empresa
    }
}
