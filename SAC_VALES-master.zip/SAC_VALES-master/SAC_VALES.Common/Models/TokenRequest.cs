﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SAC_VALES.Common.Models
{
    public class TokenRequest
    {
        public string Username { get; set; }

        public string Contraseña { get; set; }
    }
}
