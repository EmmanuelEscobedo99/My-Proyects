﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SAC_VALES.Common.Models
{
    public class ClieValesRequest
    {
        public int ClieId { get; set; }
    }
}
