﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SAC_VALES.Common.Models
{
    public class PagosByValeRequest
    {
        public int ValeId { get; set; }
    }
}
