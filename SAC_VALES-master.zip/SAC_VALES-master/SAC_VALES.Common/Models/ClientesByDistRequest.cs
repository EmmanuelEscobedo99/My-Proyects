﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SAC_VALES.Common.Models
{
    public class ClientesByDistRequest
    {
        public int DistId { get; set; }
    }
}
