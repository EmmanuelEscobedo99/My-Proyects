﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SAC_VALES.Common.Helpers
{
    public interface IRegexHelper
    {
        bool IsValidEmail(string emailaddress);
    }
}
