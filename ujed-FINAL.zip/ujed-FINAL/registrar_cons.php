<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "admin";
$dbname = "ujed";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$encabezado = $_POST['encabezado'];
$nombre = $_POST['nombre'];
$curso = $_POST['curso'];
$fecha = $_POST['fecha'];	
$titulo1 = $_POST['titulo1'];
$titulo2 = $_POST['titulo2'];
//$solicitante = $_POST['selecciona'];

$sql = "INSERT INTO constancias (encabezado, nombre, curso, fecha, titulo1, titulo2, id_usuario)
VALUES ('$encabezado', '$nombre', '$curso', '$fecha', '$titulo1', '$titulo2', '2')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
