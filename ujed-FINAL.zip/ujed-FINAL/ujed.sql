Updatecheck<|||>3<|||>1
DoUsageStatistics<|||>3<|||>1
UpdatecheckLastrun<|||>1<|||>2019-08-20 10:35:38
LastUsageStatisticCall<|||>1<|||>2019-08-20 10:35:39
ColWidths_connform.ListSessions<|||>1<|||>163,50,50,50,50,50,53
ColsVisible_connform.ListSessions<|||>1<|||>0
ColPositions_connform.ListSessions<|||>1<|||>0,1,2,3,4,5,6
ColSort_connform.ListSessions<|||>1<|||>0,0
CoolBand0Index<|||>3<|||>0
CoolBand0Break<|||>3<|||>1
CoolBand0Width<|||>3<|||>1360
CoolBand1Index<|||>3<|||>1
CoolBand1Break<|||>3<|||>1
CoolBand1Width<|||>3<|||>1360
MainWinOnMonitor<|||>3<|||>0
ColWidths_MainForm.ListDatabases<|||>1<|||>150,80,50,50,50,50,50,50,50,50,120
ColsVisible_MainForm.ListDatabases<|||>1<|||>0,1,2,3,4,5,6,7,8,9,10
ColPositions_MainForm.ListDatabases<|||>1<|||>0,1,2,3,4,5,6,7,8,9,10
ColSort_MainForm.ListDatabases<|||>1<|||>0,0
ColWidths_MainForm.ListVariables<|||>1<|||>160,200,428
ColsVisible_MainForm.ListVariables<|||>1<|||>0,1,2
ColPositions_MainForm.ListVariables<|||>1<|||>0,1,2
ColSort_MainForm.ListVariables<|||>1<|||>0,0
ColWidths_MainForm.ListStatus<|||>1<|||>160,428,100,100
ColsVisible_MainForm.ListStatus<|||>1<|||>0,1,2,3
ColPositions_MainForm.ListStatus<|||>1<|||>0,1,2,3
ColSort_MainForm.ListStatus<|||>1<|||>0,0
ColWidths_MainForm.ListProcesses<|||>1<|||>70,80,80,80,80,50,50,211
ColsVisible_MainForm.ListProcesses<|||>1<|||>0,1,2,3,4,5,6,7
ColPositions_MainForm.ListProcesses<|||>1<|||>0,1,2,3,4,5,6,7
ColSort_MainForm.ListProcesses<|||>1<|||>0,1
ColWidths_MainForm.ListCommandStats<|||>1<|||>120,100,100,100,368
ColsVisible_MainForm.ListCommandStats<|||>1<|||>0,1,2,3,4
ColPositions_MainForm.ListCommandStats<|||>1<|||>0,1,2,3,4
ColSort_MainForm.ListCommandStats<|||>1<|||>1,1
ColWidths_MainForm.ListTables<|||>1<|||>120,70,70,120,120,70,100,50,70,70,70,70,70,90,120,70,70,70,50
ColsVisible_MainForm.ListTables<|||>1<|||>0,1,2,3,4,5,6,18
ColPositions_MainForm.ListTables<|||>1<|||>0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18
ColSort_MainForm.ListTables<|||>1<|||>2,0
LastSessions<|||>1<|||>Estres
LastActiveSession<|||>1<|||>Estres
MainWinMaximized<|||>3<|||>1
Theme<|||>1<|||>Windows
SQL Attr Comment Foreground<|||>3<|||>8421504
SQL Attr ConditionalComment Foreground<|||>3<|||>8421504
SQL Attr DataType Foreground<|||>3<|||>128
SQL Attr DelimitedIdentifier Foreground<|||>3<|||>32896
SQL Attr Function Foreground<|||>3<|||>8388608
SQL Attr Identifier Foreground<|||>3<|||>32896
SQL Attr Key Foreground<|||>3<|||>16711680
SQL Attr Number Foreground<|||>3<|||>8388736
SQL Attr String Foreground<|||>3<|||>32768
SQL Attr Symbol Foreground<|||>3<|||>16711680
SQL Attr TableName Foreground<|||>3<|||>16711935
SQL Attr Variable Foreground<|||>3<|||>8388736
FieldColor_Binary<|||>3<|||>8388736
FieldColor_Datetime<|||>3<|||>128
FieldColor_Numeric<|||>3<|||>16711680
FieldColor_Other<|||>3<|||>32896
FieldColor_Real<|||>3<|||>16711752
FieldColor_Spatial<|||>3<|||>8421376
FieldColor_Text<|||>3<|||>32768
ColWidths_frmTableEditor.listColumns<|||>1<|||>38,100,156,90,60,65,50,119,130,140,100,100
ColsVisible_frmTableEditor.listColumns<|||>1<|||>0,1,2,3,4,5,6,7,8,9,10,11
ColPositions_frmTableEditor.listColumns<|||>1<|||>0,1,2,3,4,5,6,7,8,9,10,11
ColSort_frmTableEditor.listColumns<|||>1<|||>-1,0
ColWidths_frmTableEditor.treeIndexes<|||>1<|||>434,100,80
ColsVisible_frmTableEditor.treeIndexes<|||>1<|||>0,1,2
ColPositions_frmTableEditor.treeIndexes<|||>1<|||>0,1,2
ColSort_frmTableEditor.treeIndexes<|||>1<|||>-1,0
ColWidths_frmTableEditor.listForeignKeys<|||>1<|||>200,80,100,80,80,80
ColsVisible_frmTableEditor.listForeignKeys<|||>1<|||>0,1,2,3,4,5
ColPositions_frmTableEditor.listForeignKeys<|||>1<|||>0,1,2,3,4,5
ColSort_frmTableEditor.listForeignKeys<|||>1<|||>-1,0
SessionManager_WindowLeft<|||>3<|||>378
SessionManager_WindowTop<|||>3<|||>243
dbtreewidth<|||>3<|||>213
SessionManager_WindowHeight<|||>3<|||>432
FileDialogEncoding_MainForm<|||>3<|||>0
FilterPanel<|||>3<|||>0
querymemoheight<|||>3<|||>113
SQLFile0<|||>1<|||>C:\Users\Ricardo PDB\AppData\Roaming\HeidiSQL\Backups\query-tab-2019-07-18_16-10-23-866.sql
SQLFile1<|||>1<|||>C:\xampp\htdocs\ujed.sql
Servers\Estres\SessionCreated<|||>1<|||>2019-02-15 09:07:16
Servers\Estres\Host<|||>1<|||>estresacademico.proyectosutd.com
Servers\Estres\WindowsAuth<|||>3<|||>0
Servers\Estres\User<|||>1<|||>proyec23_uestres
Servers\Estres\Password<|||>1<|||>79797930686365776E766366333B37392
Servers\Estres\LoginPrompt<|||>3<|||>0
Servers\Estres\Port<|||>1<|||>3306
Servers\Estres\NetType<|||>3<|||>0
Servers\Estres\Compressed<|||>3<|||>0
Servers\Estres\LocalTimeZone<|||>3<|||>0
Servers\Estres\QueryTimeout<|||>3<|||>0
Servers\Estres\KeepAlive<|||>3<|||>20
Servers\Estres\FullTableStatus<|||>3<|||>1
Servers\Estres\Databases<|||>1<|||>proyec23_estres
Servers\Estres\Comment<|||>1<|||>
Servers\Estres\StartupScriptFilename<|||>1<|||>
Servers\Estres\TreeBackground<|||>3<|||>536870911
Servers\Estres\SSHtunnelHost<|||>1<|||>
Servers\Estres\SSHtunnelHostPort<|||>3<|||>0
Servers\Estres\SSHtunnelUser<|||>1<|||>
Servers\Estres\SSHtunnelPassword<|||>1<|||>3
Servers\Estres\SSHtunnelTimeout<|||>3<|||>4
Servers\Estres\SSHtunnelPrivateKey<|||>1<|||>
Servers\Estres\SSHtunnelPort<|||>3<|||>3307
Servers\Estres\SSL_Active<|||>3<|||>0
Servers\Estres\SSL_Key<|||>1<|||>
Servers\Estres\SSL_Cert<|||>1<|||>
Servers\Estres\SSL_CA<|||>1<|||>
Servers\Estres\SSL_Cipher<|||>1<|||>
Servers\Estres\RefusedCount<|||>3<|||>5
Servers\Estres\ServerVersionFull<|||>1<|||>5.6.41-84.1 - Percona Server (GPL), Release 84.1, Revision b308619
Servers\Estres\ConnectCount<|||>3<|||>17
Servers\Estres\ServerVersion<|||>3<|||>50641
Servers\Estres\LastConnect<|||>1<|||>2019-08-20 10:35:58
Servers\Estres\lastUsedDB<|||>1<|||>proyec23_estres
Servers\IIC\SessionCreated<|||>1<|||>2019-07-18 16:08:33
Servers\IIC\Host<|||>1<|||>ftp01.servage.net
Servers\IIC\WindowsAuth<|||>3<|||>0
Servers\IIC\CleartextPluginEnabled<|||>3<|||>0
Servers\IIC\User<|||>1<|||>1006416_es90532
Servers\IIC\Password<|||>1<|||>497578786B653836373E6
Servers\IIC\LoginPrompt<|||>3<|||>0
Servers\IIC\Port<|||>1<|||>3306
Servers\IIC\NetType<|||>3<|||>0
Servers\IIC\Compressed<|||>3<|||>0
Servers\IIC\LocalTimeZone<|||>3<|||>0
Servers\IIC\QueryTimeout<|||>3<|||>30
Servers\IIC\KeepAlive<|||>3<|||>20
Servers\IIC\FullTableStatus<|||>3<|||>1
Servers\IIC\Databases<|||>1<|||>1006416-iic
Servers\IIC\Library<|||>1<|||>libmariadb.dll
Servers\IIC\Comment<|||>1<|||>
Servers\IIC\StartupScriptFilename<|||>1<|||>
Servers\IIC\TreeBackground<|||>3<|||>536870911
Servers\IIC\SSHtunnelHost<|||>1<|||>
Servers\IIC\SSHtunnelHostPort<|||>3<|||>22
Servers\IIC\SSHtunnelUser<|||>1<|||>
Servers\IIC\SSHtunnelPassword<|||>1<|||>2
Servers\IIC\SSHtunnelTimeout<|||>3<|||>4
Servers\IIC\SSHtunnelPrivateKey<|||>1<|||>
Servers\IIC\SSHtunnelPort<|||>3<|||>3307
Servers\IIC\SSL_Active<|||>3<|||>0
Servers\IIC\SSL_Key<|||>1<|||>
Servers\IIC\SSL_Cert<|||>1<|||>
Servers\IIC\SSL_CA<|||>1<|||>
Servers\IIC\SSL_Cipher<|||>1<|||>
Servers\IIC\RefusedCount<|||>3<|||>1
Servers\localhost\SessionCreated<|||>1<|||>2019-02-15 09:09:03
Servers\localhost\Host<|||>1<|||>127.0.0.1
Servers\localhost\WindowsAuth<|||>3<|||>0
Servers\localhost\User<|||>1<|||>root
Servers\localhost\Password<|||>1<|||>696C7571768
Servers\localhost\LoginPrompt<|||>3<|||>0
Servers\localhost\Port<|||>1<|||>3306
Servers\localhost\NetType<|||>3<|||>0
Servers\localhost\Compressed<|||>3<|||>0
Servers\localhost\LocalTimeZone<|||>3<|||>0
Servers\localhost\QueryTimeout<|||>3<|||>0
Servers\localhost\KeepAlive<|||>3<|||>20
Servers\localhost\FullTableStatus<|||>3<|||>1
Servers\localhost\Databases<|||>1<|||>
Servers\localhost\Comment<|||>1<|||>
Servers\localhost\StartupScriptFilename<|||>1<|||>
Servers\localhost\TreeBackground<|||>3<|||>536870911
Servers\localhost\SSHtunnelHost<|||>1<|||>
Servers\localhost\SSHtunnelHostPort<|||>3<|||>0
Servers\localhost\SSHtunnelUser<|||>1<|||>
Servers\localhost\SSHtunnelPassword<|||>1<|||>6
Servers\localhost\SSHtunnelTimeout<|||>3<|||>4
Servers\localhost\SSHtunnelPrivateKey<|||>1<|||>
Servers\localhost\SSHtunnelPort<|||>3<|||>3307
Servers\localhost\SSL_Active<|||>3<|||>0
Servers\localhost\SSL_Key<|||>1<|||>
Servers\localhost\SSL_Cert<|||>1<|||>
Servers\localhost\SSL_CA<|||>1<|||>
Servers\localhost\SSL_Cipher<|||>1<|||>
Servers\localhost\ServerVersionFull<|||>1<|||>10.3.15-MariaDB - mariadb.org binary distribution
Servers\localhost\ConnectCount<|||>3<|||>5
Servers\localhost\ServerVersion<|||>3<|||>100315
Servers\localhost\LastConnect<|||>1<|||>2019-07-18 16:10:02
Servers\localhost\lastUsedDB<|||>1<|||>ujed
Servers\localhost\RefusedCount<|||>3<|||>3
Servers\SEC\SessionCreated<|||>1<|||>2019-06-11 13:33:21
Servers\SEC\Host<|||>1<|||>ftp01.servage.net
Servers\SEC\WindowsAuth<|||>3<|||>0
Servers\SEC\User<|||>1<|||>1006416_re98983
Servers\SEC\Password<|||>1<|||>467275756876737271676871666C64623533343B3
Servers\SEC\LoginPrompt<|||>3<|||>0
Servers\SEC\Port<|||>1<|||>3306
Servers\SEC\NetType<|||>3<|||>0
Servers\SEC\Compressed<|||>3<|||>0
Servers\SEC\LocalTimeZone<|||>3<|||>0
Servers\SEC\QueryTimeout<|||>3<|||>30
Servers\SEC\KeepAlive<|||>3<|||>20
Servers\SEC\FullTableStatus<|||>3<|||>1
Servers\SEC\Databases<|||>1<|||>1006416-correspondencia
Servers\SEC\Comment<|||>1<|||>
Servers\SEC\StartupScriptFilename<|||>1<|||>
Servers\SEC\TreeBackground<|||>3<|||>536870911
Servers\SEC\SSHtunnelHost<|||>1<|||>
Servers\SEC\SSHtunnelHostPort<|||>3<|||>22
Servers\SEC\SSHtunnelUser<|||>1<|||>
Servers\SEC\SSHtunnelPassword<|||>1<|||>5
Servers\SEC\SSHtunnelTimeout<|||>3<|||>4
Servers\SEC\SSHtunnelPrivateKey<|||>1<|||>
Servers\SEC\SSHtunnelPort<|||>3<|||>3307
Servers\SEC\SSL_Active<|||>3<|||>0
Servers\SEC\SSL_Key<|||>1<|||>
Servers\SEC\SSL_Cert<|||>1<|||>
Servers\SEC\SSL_CA<|||>1<|||>
Servers\SEC\SSL_Cipher<|||>1<|||>
Servers\SEC\RefusedCount<|||>3<|||>40
Servers\SEC\CleartextPluginEnabled<|||>3<|||>0
Servers\SEC\Library<|||>1<|||>libmariadb.dll
