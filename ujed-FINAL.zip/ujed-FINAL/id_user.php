<?php 

	/**
	 * 
	 */
	/**
	 * 
	 */
	class IdUser
	{
		
		function __construct($id_user)
		{
			$servername = "localhost";
			$username = "root";
			$password = "admin";
			$dbname = "ujed";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);
			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			} 

			$sql2 = "SELECT nombre_usuario FROM `usuarios`";

			//variable id

			if ($sql2 == "secretaria@gmail.com") {
				$id_user = "1";
			}
			elseif ($sql2 == "admin@gmail.com") {
				$id_user = "2";
			}

			if ($conn->query($sql) === TRUE) {
			    echo "New record created successfully";
			} else {
			    echo "Error: " . $sql . "<br>" . $conn->error;
			}

			$conn->close();
		}
	}

 ?>