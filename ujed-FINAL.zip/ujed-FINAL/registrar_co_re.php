<?php

	session_start();
	$servername = "localhost";
	$username = "root";
	$password = "admin";
	$dbname = "ujed";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	} 

	$oficio = $_POST['oficio'];
	$fecha = $_POST['fecha'];
	$asunto = $_POST['asunto'];
	//$procedencia = $_POST['procedencia'];
	$destinatario = $_POST['destinatario'];
	//$value = $_POST['respuesta'];
	$solicitante = $_POST['selecciona'];
	//$username2 = "";
	//$id_user = "";

	//$username2=session_id();

	/*echo "$username2";

	if ($username2 == "a15lngkfnmn8vlajv204gi2j52") {
		$id_user = "2";
	}*/

	if (isset($_POST['respuesta']) != "") {
		if (is_array($_POST['respuesta'])) {
			while (list($key, $value) = each($_POST['respuesta'])) {
				$sql = "INSERT INTO co_recibida (no_oficio, asunto, fecha, procedencia, destinatario, req_respuesta, id_usuario)
				VALUES ('$oficio', '$asunto', '$fecha', '$solicitante', '$destinatario', $value, '2')";
			}
		}
	}elseif (isset($_POST['respuesta']) == ""){
		$value = 'false';
		$sql = "INSERT INTO co_recibida (no_oficio, asunto, fecha, procedencia, destinatario, req_respuesta, id_usuario)
				VALUES ('$oficio', '$asunto', '$fecha', '$solicitante', '$destinatario', $value, '2')";
	}


	if ($conn->query($sql) === TRUE) {
	    echo "New record created successfully";
	} else {
	    echo "Error: " . $sql . "<br>" . $conn->error;
	}



	$conn->close();
?>
