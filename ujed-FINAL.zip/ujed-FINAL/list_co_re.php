<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Correspondencia</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/Animated-Type-Heading.css">
    <link rel="stylesheet" href="assets/css/Box-panels.css">
    <link rel="stylesheet" href="assets/css/Box-panels.css">
    <link rel="stylesheet" href="assets/css/Data-Table.css">
    <link rel="stylesheet" href="assets/css/Data-Table.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/mloureiro1973-login.css">
    <link rel="stylesheet" href="assets/css/MUSA_panel-table.css">
    <link rel="stylesheet" href="assets/css/mloureiro1973-login.css">
    <link rel="stylesheet" href="assets/css/MUSA_panel-table.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/css/Newsletter-Subscription-Form.css">
    <link rel="stylesheet" href="assets/css/Popup-Element-Overlay.css">
    <link rel="stylesheet" href="assets/css/Popup-Element-Overlay.css">
    <link rel="stylesheet" href="assets/css/Sidebar-Menu.css">
    <link rel="stylesheet" href="assets/css/Sidebar-Menu.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="visible" id="sidebar-wrapper" style="width:210px;background-color:rgb(218,0,20);background-image:url(&quot;assets/img/435178.jpg&quot;);background-position:center;height:668px;margin-top:0px;">
        <ul class="sidebar-nav" style="width:180px;height:508px;padding:-2px;padding-top:38px;padding-right:0px;padding-left:-7px;margin:0px;">
            <li data-bs-hover-animate="pulse" class="sidebar-brand" style="background-image:url(&quot;assets/img/logo2-01.png&quot;);height:160px;background-size:contain;background-repeat:no-repeat;background-position:top;width:200px;margin-top:-26px;"> </li>
            <li> <a href="list_co_env.php" style="color:rgb(255,255,255);width:210px;">Correspondencia Enviada</a><a href="list_co_re.php" style="color:rgb(255,255,255);width:210px;">Correspondencia Recibida</a></li>
            <li> </li>
            <li> <a href="list_cons.php" style="color:rgb(255,255,255);width:210px;">Lista Constancias</a><a href="control_panel.html" style="color:rgb(255,255,255);width:210px;">Panel de Control</a><a href="logout.php" style="color:rgb(255,255,255);width:210px;">Cerrar Sesión</a></li>
            <li
                class="sidebar-brand" style="background-image:url(&quot;assets/img/LOGO IIC 2017.jpg&quot;);height:173px;background-size:contain;background-repeat:no-repeat;background-position:top;width:210px;margin-top:112px;padding-top:8px;padding-right:0px;"> </li>
        </ul>
    </div>
    <div class="col" style="padding-left:230px;padding-top:20px;margin-left:0px;width:2000px;">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet'type='text/css'>

<div class="container">
    <div class="row">
    
        <div class="col-md-10 col-md-offset-1">

            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="row">
                  <div class="col col-xs-6">
                    <h1 class="panel-title">Correspondencia Recibida</h1>
                  </div>
                  <div class="col col-xs-6 text-right">
                    <button type="button" class="btn btn-sm btn-primary btn-create" style="background-color:rgb(218,0,20);border-color:rgb(218,0,20);" target="_blank" onclick="window.open('new_co_re.html'); window.location.href = 'list_co_re.php'">Nueva</button>
                  </div>
                </div>
              </div>
                <?php 

              $server = "localhost";
              $usuario = "root";
              $contrasena = "admin";
              $bd = "ujed";

              $conexion = mysqli_connect($server, $usuario, $contrasena, $bd) or die ("Error en la conexion");

              $sql = mysqli_query($conexion, "SELECT no_oficio, asunto, fecha, procedencia, destinatario, req_respuesta FROM `co_recibida` WHERE 1") or die ("Error al traer los datos");
              ?>
              <div class="panel-body">
                <table class="table table-striped table-bordered table-list">
                  <thead>
                    <tr>
                        <th><em class="fa fa-cog"></em></th>
                        <th class="hidden-xs">No. Oficio</th>
                        <th>Fecha</th>
                        <th>Asunto</th>
                        <th>Destinatario</th>
                        <th>Procedencia</th>
                        <th>¿Requiere Respuesta?</th>
                    </tr> 
                  </thead>
                  <tbody>
                    <?php 
                      while ($extraido = mysqli_fetch_array($sql)) 
                    {?>
                      <?php 
                        if($extraido['req_respuesta'] == 1){
                            $extraido['req_respuesta'] == "Si";
                        }else{
                          $extraido['req_respuesta'] == "No";
                        }
                       ?>
                          <tr>
                            <td align="center">
                              <a class="btn btn-default"><em class="fa fa-pencil"></em></a>
                              <a class="btn btn-danger"><em class="fa fa-trash"></em></a>
                            </td>
                              <td class="hidden-xs"><?php echo $extraido['no_oficio']?></td>
                              <td><?php echo $extraido['fecha']?></td>
                              <td><?php echo $extraido['asunto']?></td>
                              <td><?php echo $extraido['destinatario']?></td>
                              <td><?php echo $extraido['procedencia']?></td>
                              <td><?php echo $extraido['req_respuesta']?></td>
                          </tr>
                        <?php  }?>
                        <?php  
                        mysqli_close($conexion);
                        ?>
                        </tbody>
                </table>
            
              </div>
            </div>

</div></div></div></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/Animated-Type-Heading.js"></script>
    <script src="assets/js/bs-animation.js"></script>
    <script src="assets/js/Popup-Element-Overlay.js"></script>
    <script src="assets/js/Sidebar-Menu.js"></script>
</body>

</html>