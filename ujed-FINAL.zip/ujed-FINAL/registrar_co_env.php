<?php
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "admin";
    $dbname = "ujed";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 

    $oficio = $_POST['oficio'];
    $fecha = $_POST['fecha'];
    $asunto = $_POST['asunto'];
    $destinatario = $_POST['destinatario'];	
    $solicitante = $_POST['selecciona'];

    $sql = "INSERT INTO co_enviada (no_oficio, asunto, fecha, solicitante, destinatario, id_usuario)
    VALUES ('$oficio', '$asunto', '$fecha', '$solicitante', '$destinatario', '2')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
?>
