<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Correspondencia</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/Animated-Type-Heading.css">
    <link rel="stylesheet" href="assets/css/Box-panels.css">
    <link rel="stylesheet" href="assets/css/Box-panels.css">
    <link rel="stylesheet" href="assets/css/Data-Table.css">
    <link rel="stylesheet" href="assets/css/Data-Table.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/mloureiro1973-login.css">
    <link rel="stylesheet" href="assets/css/MUSA_panel-table.css">
    <link rel="stylesheet" href="assets/css/mloureiro1973-login.css">
    <link rel="stylesheet" href="assets/css/MUSA_panel-table.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/css/Newsletter-Subscription-Form.css">
    <link rel="stylesheet" href="assets/css/Popup-Element-Overlay.css">
    <link rel="stylesheet" href="assets/css/Popup-Element-Overlay.css">
    <link rel="stylesheet" href="assets/css/Sidebar-Menu.css">
    <link rel="stylesheet" href="assets/css/Sidebar-Menu.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="background-image:url(&quot;assets/img/435178.jpg&quot;);">
    <div class="login-card">
        <div>
            <h2 class="text-center" style="margin-bottom:0px;">Sistema de Correspondencia</h2>
        </div><img class="rounded img-fluid profile-img-card" src="assets/img/logo2-01.png" style="background-image:url(&quot;assets/img/logo2-01.png&quot;);width:160px;height:250px;margin-left:55px;padding:0px;">
        <p class="profile-name-card"> </p>
        <form class="form-signin" action="" method="post">
            <?php

                if (isset($errorLogin)) {
                    echo $errorLogin;
                }

            ?>
            <input class="form-control" type="email" required="" placeholder="Usuario" autofocus="" id="username" name="username"><input class="form-control" type="password" required="" placeholder="Contraseña" id="password" name="password"><button class="btn btn-primary btn-block btn-lg btn-signin"
                type="submit" name="login" style="background-color:rgb(218,0,20);">Entrar</button></form><a href="#passwordRecuperar.html" class="forgot-password" style="color:rgb(17,114,154);">Recuperar contraseña?</a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/Animated-Type-Heading.js"></script>
    <script src="assets/js/bs-animation.js"></script>
    <script src="assets/js/Popup-Element-Overlay.js"></script>
    <script src="assets/js/Sidebar-Menu.js"></script>
</body>

</html>