<?php 

$servername = "localhost";
$username = "root";
$password = "admin";
$dbname = "ujed";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


//QUERY
$sql = "SELECT * FROM `co_enviada`";


if ($conn->query($sql) === TRUE) {
	    echo "Modificado!";
	} else {
	    echo "Error: " . $sql . "<br>" . $conn->error;
	}



$conn->close();
 ?>